#include "FB.h"
#include "buddy.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void firstFit();
void bestFit();
void buddySystem();

int findLinks(list mList);
int findLargestChunk(list mList);

void printRequests(char* policy);
void printBuddyRequests();

struct request{
    bool isAlloc;
    int size;
    bool isDone;
    int memoryLeft;
    int links;
    int largestChunk;
    int actSize;
    int baseAdr;
} reqArray[1001];

int freeSpace, totSpace, totAllocs = 0;
FILE* inputFile;

int main(int argc, char* argv[]) {
    if (argc != 4) {
    printf("How to run the file:\n");
    printf("./main [Policy] [Free Space] [Input File]\n");
    printf("-----------------------------------------\n");
    printf("Available Policies:\n");
    printf("- bs = buddy system\n");
    printf("- ff = first fit\n");
    printf("- bf = best fit\n");
    exit(1);
    }

    freeSpace = totSpace = atoi(argv[2]) * 1024;
    if((inputFile = fopen(argv[3], "r")) == NULL) {
        printf("Unable to open or find file\n");
        exit(2);
    }

    if (strcmp(argv[1], "bs") == 0) buddySystem();
    else if (strcmp(argv[1], "ff") == 0) firstFit();
    else if (strcmp(argv[1], "bf") == 0) bestFit();

    fclose(inputFile);
    return 0;
}

void buddySystem() {
    tree mTree, best, node, parent;
    int size, serialNum, adjustSize, largest;
    char requestType[10];

    if (initTree(&mTree) == -1) {
        printf("Failed to create tree\n");
        exit(1);
    }

    makeRoot(&mTree, freeSpace, TRUE, -1, 0, NULL, NULL, NULL);

    while (fscanf(inputFile, "%d %s %d", &serialNum, requestType, &size) != EOF) {
        if (strcmp(requestType, "alloc") == 0) {
            best = NULL;
            treeTraverseBest(mTree, &best, size);

            adjustSize = totSpace;
            while ((adjustSize / 2) > size) {
                adjustSize /= 2;
            }
            if (best != NULL) {
                best->freeSpace = FALSE;

                while((best->blockSize / 2) > 32 && (best->blockSize / 2) > size) {
                    makeRoot(&(best->left), best->blockSize / 2, FALSE, -1, best->baseAdr, best, NULL, NULL);
                    makeRoot(&(best->right), best->blockSize / 2, TRUE, -1, best->baseAdr + (best->blockSize / 2), best, NULL, NULL);
                    best = best->left;
                }
                best->serialNum = serialNum;

                freeSpace -= best->blockSize;
                totAllocs++;

                largest = 0;
                treeFindLargestChunk(mTree, &largest);

                reqArray[serialNum].isAlloc = TRUE;
                reqArray[serialNum].size = size;
                reqArray[serialNum].actSize = adjustSize;
                reqArray[serialNum].isDone = TRUE;
                reqArray[serialNum].memoryLeft = freeSpace;
                reqArray[serialNum].largestChunk = largest;
                reqArray[serialNum].baseAdr = best->baseAdr;
            } else {
                largest = 0;
                treeFindLargestChunk(mTree, &largest);

                reqArray[serialNum].isAlloc = TRUE;
                reqArray[serialNum].size = size;
                reqArray[serialNum].actSize = adjustSize;
                reqArray[serialNum].isDone = FALSE;
                reqArray[serialNum].memoryLeft = freeSpace;
                reqArray[serialNum].largestChunk = 0;
                reqArray[serialNum].baseAdr = -1;

            }
        } else {
            node = NULL;
            treeFindSerialNum(mTree, &node, size);
            if (node != NULL) {
                node->freeSpace = TRUE;
                freeSpace += node->blockSize;

                reqArray[serialNum].isAlloc = FALSE;
                reqArray[serialNum].size = reqArray[size].size;
                reqArray[serialNum].actSize = reqArray[size].actSize;
                reqArray[serialNum].isDone = TRUE;
                reqArray[serialNum].memoryLeft = freeSpace;
                reqArray[serialNum].baseAdr = -1;

                parent = node->parent;
                while (parent != NULL && parent->left->freeSpace && parent->right->freeSpace) {
                    freeTreeNode(&(parent->left));
                    freeTreeNode(&(parent->right));
                    parent->freeSpace = TRUE;
                    parent = parent->parent;
                }

                largest = 0;
                treeFindLargestChunk(mTree, &largest);

                reqArray[serialNum].largestChunk = largest;
            } else {
                largest = 0;
                treeFindLargestChunk(mTree, &largest);

                reqArray[serialNum].isAlloc = FALSE;
                reqArray[serialNum].size = reqArray[size].size;
                reqArray[serialNum].actSize = reqArray[size].actSize;
                reqArray[serialNum].isDone = FALSE;
                reqArray[serialNum].memoryLeft = freeSpace;
                reqArray[serialNum].largestChunk = largest;
                reqArray[serialNum].baseAdr = -1;
            }
        }
    }
    printBuddyRequests();
    destroyTree(&mTree);
}

void firstFit() {
    list mList, currentList;
    int serialNum, size;
    char requestType[10];

    if (initList(&mList) == -1) {
        printf("Unable to initialize list\n");
        exit(3);
    }

    insertAfter(&mList, NULL, freeSpace, TRUE, -1);

    while(fscanf(inputFile, "%d %s %d", &serialNum, requestType, &size) != EOF) {
        if(strcmp(requestType, "alloc") == 0) {
            currentList = NULL;

            while ((currentList = listIterator(mList, currentList)) != NULL) {

                if (currentList->freeSpace == TRUE && currentList->blockSize > size) {
                    insertAfter(&mList, currentList, currentList->blockSize - size, TRUE, -1);

                    currentList->blockSize = size;
                    currentList->freeSpace = FALSE;
                    currentList->serialNum = serialNum;

                    freeSpace -= size;
                    totAllocs++;

                    reqArray[serialNum].isAlloc = TRUE;
                    reqArray[serialNum].size = size;
                    reqArray[serialNum].isDone = TRUE;
                    reqArray[serialNum].memoryLeft = freeSpace;
                    reqArray[serialNum].links = findLinks(mList);
                    reqArray[serialNum].largestChunk = findLargestChunk(mList);

                    break;
                }
            }

            if (currentList == NULL) {
                reqArray[serialNum].isAlloc = TRUE;
                reqArray[serialNum].size = size;
                reqArray[serialNum].isDone = FALSE;
                reqArray[serialNum].memoryLeft = freeSpace;
                reqArray[serialNum].links = findLinks(mList);
                reqArray[serialNum].largestChunk = findLargestChunk(mList);

            }
        } else {
            currentList = NULL;

            while ((currentList = listIterator(mList, currentList)) != NULL) {
                if (currentList->serialNum == size) {
                    currentList->freeSpace = TRUE;
                    currentList->serialNum = -1;

                    freeSpace += currentList->blockSize;

                    reqArray[serialNum].isAlloc = FALSE;
                    reqArray[serialNum].size = currentList->blockSize;
                    reqArray[serialNum].isDone = TRUE;
                    reqArray[serialNum].memoryLeft = freeSpace;

                    if (currentList->next != NULL && currentList->next->freeSpace == TRUE) {
                        currentList->blockSize += currentList->next->blockSize;
                        deleteNode(&mList, currentList->next);
                    }

                    if (currentList->prev != NULL && currentList->prev->freeSpace == TRUE) {
                        currentList->prev->blockSize += currentList->blockSize;
                        deleteNode(&mList, currentList);
                    }

                    reqArray[serialNum].links = findLinks(mList);
                    reqArray[serialNum].largestChunk = findLargestChunk(mList);

                    break;
                }
            }
            if (currentList == NULL) {
                reqArray[serialNum].isAlloc = FALSE;
                reqArray[serialNum].size = 0;
                reqArray[serialNum].isDone = FALSE;
                reqArray[serialNum].memoryLeft = freeSpace;
                reqArray[serialNum].links = findLinks(mList);
                reqArray[serialNum].largestChunk = findLargestChunk(mList);
            }
        }
    }

    printRequests("First Fit");
    destroy(&mList);
}

void bestFit() {
    list mList, currentList, best;
    int serialNum, size;
    char requestType[10];

    if (initList(&mList) == -1) {
        printf("unable to initialize list\n");
        exit(3);
    }

    insertAfter(&mList, NULL, freeSpace, TRUE, -1);

    while (fscanf(inputFile, "%d %s %d", &serialNum, requestType, &size) != EOF) {
        if (strcmp(requestType, "alloc") == 0) {
            best = currentList = NULL;

            while ((currentList = listIterator(mList, currentList)) != NULL) {
                if(currentList->freeSpace && currentList->blockSize > size) {
                    if(best == NULL || currentList->blockSize < best->blockSize) {
                        best = currentList;
                    }
                }
            }

            if (best != NULL) {
                insertAfter(&mList, best, best->blockSize - size, TRUE, -1);

                best->blockSize = size;
                best->freeSpace = FALSE;
                best->serialNum = serialNum;

                freeSpace -= size;
                totAllocs++;

                reqArray[serialNum].isAlloc = TRUE;
                reqArray[serialNum].size = size;
                reqArray[serialNum].isDone = TRUE;
                reqArray[serialNum].memoryLeft = freeSpace;
                reqArray[serialNum].links = findLinks(mList);
                reqArray[serialNum].largestChunk = findLargestChunk(mList);
            } else {
                reqArray[serialNum].isAlloc = TRUE;
                reqArray[serialNum].size = size;
                reqArray[serialNum].isDone = FALSE;
                reqArray[serialNum].memoryLeft = freeSpace;
                reqArray[serialNum].links = findLinks(mList);
                reqArray[serialNum].largestChunk = findLargestChunk(mList);

            }
        } else {
            currentList = NULL;

            while ((currentList = listIterator(mList, currentList)) != NULL) {
                if(currentList->serialNum == size) {
                    currentList->freeSpace = TRUE;
                    currentList->serialNum = -1;

                    freeSpace += currentList->blockSize;

                    reqArray[serialNum].isAlloc = FALSE;
                    reqArray[serialNum].size = currentList->blockSize;
                    reqArray[serialNum].isDone = TRUE;
                    reqArray[serialNum].memoryLeft = freeSpace;

                    if(currentList->next != NULL && currentList->next->freeSpace == TRUE) {
                        currentList->blockSize += currentList->next->blockSize;
                        deleteNode(&mList, currentList->next);
                    }

                    if (currentList->prev != NULL && currentList->prev->freeSpace == TRUE) {
                        currentList->prev->blockSize += currentList->blockSize;
                        deleteNode(&mList, currentList);
                    }

                    reqArray[serialNum].links = findLinks(mList);
                    reqArray[serialNum].largestChunk = findLargestChunk(mList);

                    break;
                }
            }
            if (currentList == NULL) {
                reqArray[serialNum].isAlloc = FALSE;
                reqArray[serialNum].size = 0;
                reqArray[serialNum].isDone = FALSE;
                reqArray[serialNum].memoryLeft = freeSpace;
                reqArray[serialNum].links = findLinks(mList);
                reqArray[serialNum].largestChunk = findLargestChunk(mList);
            }
        }
    }

    printRequests("Best Fit");
    destroy(&mList);
}

int findLinks(list mList) {
    list currentList = NULL;
    int count = 0;

    while ((currentList = listIterator(mList, currentList)) != NULL) {
        if (currentList->freeSpace) {
            count++;
        }
    }

    return count;
}

int findLargestChunk(list mList) {
    list currentList = NULL;
    int largest = 0;

    while ((currentList = listIterator(mList, currentList)) != NULL) {
        if (currentList->freeSpace && currentList->blockSize > largest) {
            largest = currentList->blockSize;
        }
    }

    return largest;
}

void printRequests(char* policy) {
    int i;

    printf("MANAGEMENT POLICY = %s        POOL SIZE = %d KB\n\n", policy, freeSpace / 1024);
    printf("TOTAL ALLOCATIONS: %d\n", totAllocs);
    printf("SERIAL     TYPE      SIZE  DONE   TOT-MEM   LINKS  LARGEST-CHUNK\n");
    printf("----------------------------------------------------------------\n");

    for (i = 1; i < 1001; i++) {
        printf("%4d %10s %9d %5s %9d %6d %10d\n", i,
               reqArray[i].isAlloc ? "alloc" : "free",
               reqArray[i].size,
               reqArray[i].isDone ? "YES" : "NO",
               reqArray[i].memoryLeft,
               reqArray[i].links,
               reqArray[i].largestChunk);
    }
}

void printBuddyRequests() {
    int i;

    printf("MANAGEMENT POLICY = Buddy System        POOL SIZE = %d KB\n\n", freeSpace / 1024);
    printf("TOTAL ALLOCATIONS: %d\n", totAllocs);
    printf("SERIAL   TYPE     SIZE   ACT-SIZE  DONE  BASE-ADR   TOT-MEM  LARGEST-CHUNK\n");
    printf("--------------------------------------------------------------------------\n");

    for (i = 1; i < 1001; i++) {
        printf("%4d %8s %8d %9d %5s %9d %9d %10d\n", i,
               reqArray[i].isAlloc ? "alloc" : "free",
               reqArray[i].size,
               reqArray[i].actSize,
               reqArray[i].isDone ? "YES" : "NO",
               reqArray[i].baseAdr,
               reqArray[i].memoryLeft,
               reqArray[i].largestChunk);
    }
}
