#include "FB.h"
#include <stdlib.h>
#include <stdio.h>

int allocateNode(list* listP, int blockSize, bool freeSpace, int serial){
    list mList = (list)malloc(sizeof(node));

    if (mList == NULL) {
        return -1;
    }

    *listP = mList;
    mList->blockSize = blockSize;
    mList->freeSpace = freeSpace;
    mList->serialNum = serial;

    return 0;
}

int deleteNode(list* listP, list node) {
    if (emptyList(*listP)) {
        return -1;
    }

    list prev = node->prev;
    list next = node->next;

    if (*listP == node) {
        *listP = (*listP)->next;
        (*listP)->prev = NULL;
    } else {
        if (prev == NULL) {
            return -1;
        } else {
            prev->next = next;
            if (next != NULL) {
                next->prev = prev;
            }
        }
    }
    freeNode(&node);
    return 0;
}

void destroy(list* listP) {
    if (!emptyList(*listP)) {
        destroy(&(*listP)->next);
        freeNode(listP);
    }
}

bool emptyList(list mList) {
    return (mList == NULL) ? TRUE : FALSE;
}

void freeNode(list* listP) {
    free(*listP);
    *listP = NULL;
}

int initList(list* listP) {
    *listP = NULL;
    return 0;
}

int insertAfter(list* listP, list node, int blockSize, bool freeSpace, int serial) {
    list mList, next;

    if (allocateNode(&mList, blockSize, freeSpace, serial) == -1) {
        return -1;
    }

    if (emptyList(*listP)) {
        mList->next = mList->prev = NULL;
        *listP = mList;
    } else {
        next = node->next;
        node->next = mList;
        mList->prev = node;
        mList->next = next;
        if (next != NULL) {
            next->prev = mList;
        }
    }
    return 0;
}

list listIterator(list mList, list lastNode) {
    return (lastNode == NULL) ? mList : lastNode->next;
}
