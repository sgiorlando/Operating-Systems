#include "buddysys.h"

int allocateTreeNode(tree* treeP, int blockSize, bool freeSpace, int serial, int baseAdr) {
    tree mTree = (tree)malloc(sizeof(treeNode));
    if (mTree == NULL) {
        return -1;
    }

    *treeP = mTree;
    mTree->blockSize = blockSize;
    mTree->freeSpace = freeSpace;
    mTree->serialNum = serial;
    mTree->baseAdr = baseAdr;
    mTree->parent = NULL;
    mTree->left = NULL;
    mTree->right = NULL;

    return 0;
}

void freeTreeNode(tree* treeP) {
    free(*treeP);
    *treeP = NULL;
}

int initTree(tree* treeP) {
    *treeP = NULL;
    return 0;
}

bool emptyTree(tree mTree) {
    return(mTree == NULL) ? TRUE : FALSE;
}

int makeRoot(tree* treeP, int blockSize, bool freeSpace, int serial, int baseAdr,
            tree parent, tree left, tree right) {
    if (emptyTree(*treeP) == FALSE) {
        return -1;
    }
    if (allocateTreeNode(treeP, blockSize, freeSpace, serial, baseAdr) == -1) {
        return -1;
    }

    (*treeP)->parent = parent;
    (*treeP)->left = left;
    (*treeP)->right = right;

    return 0;
}

void destroyTree(tree* treeP) {
    if (emptyTree(*treeP) == FALSE) {
        destroyTree(&(*treeP)->left);
        destroyTree(&(*treeP)->right);
        freeTreeNode(treeP);
    }
}

int treeFindSerialNum(tree mTree, tree* node, int size) {
    if (emptyTree(mTree) == TRUE) {
        return 0;
    }

    if (mTree->serialNum == size) {
        *node = mTree;
    } else {
        treeFindSerialNum(mTree->left, node, size);
        treeFindSerialNum(mTree->right, node, size);
    }

    return 0;
}

int treeFindLargestChunk(tree mTree, int* largest) {
    if (emptyTree(mTree) == TRUE) {
        return 0;
    }

    treeFindLargestChunk(mTree->left, largest);
    treeFindLargestChunk(mTree->right, largest);

    if (mTree->freeSpace) {
        if (mTree->blockSize > *largest) {
            *largest = mTree->blockSize;
        }
    }

    return 0;
}

int treeTraverseBest(tree mTree, tree* best, int size) {
    if (emptyTree(mTree) == TRUE) {
        return 0;
    }

    treeTraverseBest(mTree->left, best, size);
    treeTraverseBest(mTree->right, best, size);

    if (mTree->freeSpace && mTree->blockSize > size) {
        if (*best != NULL && (*best)->blockSize > mTree->blockSize) {
            *best = mTree;
        } else if (*best == NULL) {
            *best = mTree;
        }
    }

    return 0;
}
