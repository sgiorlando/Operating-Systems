#ifndef _DATASTRUCT_H
#define _DATASTRUCT_H

#include <stdio.h>
#include <stdlib.h>

typedef enum {FALSE, TRUE} bool;
typedef struct node node, *list;

struct node {
    int blockSize;
    bool freeSpace;
    int serialNum;
    list next;
    list prev;
};

int allocateNode(list* listP, int blockSize, bool freeSpace, int serial);
int deleteNode(list* listP, list node);
void destroy(list* listP);
bool emptyList(list mList);
void freeNode(list* listP);
int initList(list* listP);
int insertAfter(list* listP, list node, int blockSize, bool freeSpace, int serial);
list listIterator(list mList, list lastNode);

#endif
