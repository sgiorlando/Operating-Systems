#ifndef _BUDDYSYS_H
#define _BUDDYSYS_H

#include "datastruct.h"

typedef struct treeNode treeNode, *tree;

struct treeNode {
    int blockSize;
    bool freeSpace;
    int serialNum;
    int baseAdr;
    tree parent;
    tree left;
    tree right;
};

int allocateTreeNode(tree* treeP, int blockSize, bool freeSpace, int serial, int baseAdr);
void freeTreeNode(tree* treeP);
int initTree(tree* treeP);
bool emptyTree(tree mTree);
int makeRoot(tree* treeP, int blockSize, bool freeSpace, int serial, int baseAdr,
    tree parent, tree left, tree right);
void destroyTree(tree* treeP);

int treeFindSerialNum(tree mTree, tree* node, int size);
int treeFindLargestChunk(tree mTree, int* largest);
int treeTraverseBest(tree mTree, tree* best, int size);

#endif
